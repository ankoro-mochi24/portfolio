import { Turbo } from "@hotwired/turbo-rails"
Turbo.start()

import "controllers";
